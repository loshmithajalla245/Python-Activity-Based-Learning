# Case Study 5: Attendance Recovery Computation
# Concepts: variables, arithmetic, loops, conditions

scenarios = [
    ("Student A", 32, 40, 75),  # attended, held, target percentage
    ("Student B", 38, 45, 80),
    ("Student C", 24, 30, 85)
]

print("ATTENDANCE RECOVERY REPORT")
for name, attended, held, target in scenarios:
    if held <= 0 or attended < 0 or attended > held:
        print(name, "- Invalid attendance data")
        continue

    current = attended / held * 100
    needed = 0

    # Assume the student attends every future class.
    while (attended + needed) / (held + needed) * 100 < target:
        needed += 1

    print(f"\n{name}")
    print(f"Classes attended: {attended}")
    print(f"Classes held:     {held}")
    print(f"Current attendance: {current:.2f}%")
    print(f"Required threshold: {target}%")
    print(f"Consecutive classes to attend: {needed}")
    print(f"Attendance after recovery: {(attended + needed) / (held + needed) * 100:.2f}%")
