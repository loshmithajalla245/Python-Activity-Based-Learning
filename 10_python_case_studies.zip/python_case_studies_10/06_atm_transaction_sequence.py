# Case Study 6: ATM Transaction Sequence Simulation
# Concepts: lists, loops, conditions, validation, arithmetic

opening_balance = 5000.00
withdrawal_limit = 3000.00

# Transactions are tuples: (type, amount)
transactions = [
    ("deposit", 1500),
    ("withdraw", 1200),
    ("withdraw", 4000),
    ("deposit", 750),
    ("withdraw", 2500),
    ("withdraw", -100),
    ("deposit", 0)
]

balance = opening_balance
accepted_deposits = 0
accepted_withdrawals = 0
rejected = 0

print("ATM TRANSACTION REPORT")
print(f"Opening balance: Rs. {opening_balance:.2f}")
print("-" * 62)

for number, transaction in enumerate(transactions, start=1):
    kind, amount = transaction
    status = "Accepted"

    if amount <= 0:
        status = "Rejected: amount must be positive"
        rejected += 1
    elif kind == "deposit":
        balance += amount
        accepted_deposits += amount
    elif kind == "withdraw":
        if amount > withdrawal_limit:
            status = "Rejected: exceeds per-transaction limit"
            rejected += 1
        elif amount > balance:
            status = "Rejected: insufficient balance"
            rejected += 1
        else:
            balance -= amount
            accepted_withdrawals += amount
    else:
        status = "Rejected: unknown transaction type"
        rejected += 1

    print(f"{number}. {kind.title():<8} Rs. {amount:>8.2f} | {status} | "
          f"Balance: Rs. {balance:.2f}")

print("-" * 62)
print(f"Accepted deposits:    Rs. {accepted_deposits:.2f}")
print(f"Accepted withdrawals: Rs. {accepted_withdrawals:.2f}")
print(f"Rejected transactions: {rejected}")
print(f"Closing balance:      Rs. {balance:.2f}")
