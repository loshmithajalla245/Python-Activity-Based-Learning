# Case Study 3: Employee Payroll and Deduction Analysis
# Concepts: variables, arithmetic, conditions, loops, formatted strings

employees = [
    ("Anil", 25000, 4000, 1500, 2000),
    ("Beena", 32000, 5000, 1000, 3500),
    ("Chirag", 45000, 7000, 2500, 5000)
]

def progressive_deduction(gross):
    # Example policy: 0% on first Rs. 20,000; 5% on next Rs. 20,000;
    # 10% on the amount above Rs. 40,000.
    deduction = 0
    if gross > 20000:
        deduction += min(gross - 20000, 20000) * 0.05
    if gross > 40000:
        deduction += (gross - 40000) * 0.10
    return deduction

print("EMPLOYEE SALARY STATEMENT")
print("-" * 88)
print(f"{'Name':<10}{'Basic':>10}{'Allow.':>10}{'Overtime':>10}"
      f"{'Incentive':>10}{'Gross':>10}{'Deduct.':>10}{'Net Pay':>10}")
print("-" * 88)

for name, basic, allowances, overtime, incentive in employees:
    gross = basic + allowances + overtime + incentive
    deduction = progressive_deduction(gross)
    net_pay = gross - deduction
    print(f"{name:<10}{basic:>10.2f}{allowances:>10.2f}{overtime:>10.2f}"
          f"{incentive:>10.2f}{gross:>10.2f}{deduction:>10.2f}{net_pay:>10.2f}")

print("-" * 88)
