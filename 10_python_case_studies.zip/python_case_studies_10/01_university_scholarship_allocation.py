# Case Study 1: University Scholarship Allocation
# Concepts: variables, data types, operators, conditions, loops, lists

applicants = [
    ["Asha", 92, [85, 90, 88], 92, 180000],
    ["Bharat", 88, [80, 82, 84], 95, 150000],
    ["Charan", 91, [90, 91, 89], 87, 220000],
    ["Divya", 91, [90, 91, 89], 90, 190000],
    ["Esha", 78, [75, 80, 72], 96, 120000]
]

MIN_AGGREGATE = 85
MIN_SUBJECT_MARK = 70
MIN_ATTENDANCE = 85
MAX_ANNUAL_INCOME = 200000

eligible = []

for applicant in applicants:
    name, aggregate, subject_marks, attendance, income = applicant
    subjects_pass = True

    for mark in subject_marks:
        if mark < MIN_SUBJECT_MARK:
            subjects_pass = False

    if (aggregate >= MIN_AGGREGATE and subjects_pass
            and attendance >= MIN_ATTENDANCE
            and income <= MAX_ANNUAL_INCOME):
        eligible.append(applicant)

# Ranking: aggregate descending, attendance descending, income ascending, name ascending.
for i in range(len(eligible)):
    for j in range(i + 1, len(eligible)):
        first = eligible[i]
        second = eligible[j]
        swap = False

        if second[1] > first[1]:
            swap = True
        elif second[1] == first[1] and second[3] > first[3]:
            swap = True
        elif (second[1] == first[1] and second[3] == first[3]
              and second[4] < first[4]):
            swap = True
        elif (second[1] == first[1] and second[3] == first[3]
              and second[4] == first[4] and second[0] < first[0]):
            swap = True

        if swap:
            eligible[i], eligible[j] = eligible[j], eligible[i]

print("SCHOLARSHIP ELIGIBILITY AND RANKING")
if len(eligible) == 0:
    print("No applicants meet all requirements.")
else:
    print("Rank | Name   | Aggregate | Attendance | Annual income")
    for rank, applicant in enumerate(eligible, start=1):
        print(f"{rank:>4} | {applicant[0]:<6} | {applicant[1]:>9}% | "
              f"{applicant[3]:>10}% | Rs. {applicant[4]}")
