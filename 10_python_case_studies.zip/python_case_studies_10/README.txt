# 10 Python Case Study Programs

These standalone programs use beginner-level Python concepts from the assigned syllabus:
variables, data types, operators, conditionals, loops, strings, lists, nested lists, tuples,
tuple unpacking, and basic pattern generation.

## Files
1. `01_university_scholarship_allocation.py`
2. `02_progressive_electricity_billing.py`
3. `03_employee_payroll_and_deductions.py`
4. `04_retail_billing_multiple_discounts.py`
5. `05_attendance_recovery_computation.py`
6. `06_atm_transaction_sequence.py`
7. `07_student_timetable_conflict_detection.py`
8. `08_nested_loop_calendar_generator.py`
9. `09_student_marks_matrix_analysis.py`
10. `10_tuple_product_catalogue_audit.py`

## How to run
Install Python 3 if needed. Open a terminal in this folder and run any program, for example:

`python 01_university_scholarship_allocation.py`

Each file contains sample data and can be run independently. The policies, rates, and records
are illustrative examples; change the constants or sample lists to match your assignment's
specific requirements.
