# Case Study 9: Student Marks Matrix Analysis
# Concepts: nested lists, loops, row/column calculations, conditions

students = ["Asha", "Bharat", "Charan", "Divya"]
subjects = ["Python", "Maths", "English"]
marks = [
    [88, 92, 81],
    [76, 84, 79],
    [95, 89, 93],
    [65, 72, 68]
]

print("STUDENT MARKS MATRIX")
print(f"{'Student':<10}" + "".join(f"{subject:>12}" for subject in subjects)
      + f"{'Total':>10}{'Average':>10}")
print("-" * 68)

student_totals = []
for i in range(len(marks)):
    total = 0
    print(f"{students[i]:<10}", end="")
    for j in range(len(marks[i])):
        print(f"{marks[i][j]:>12}", end="")
        total += marks[i][j]
    average = total / len(marks[i])
    student_totals.append(total)
    print(f"{total:>10}{average:>10.2f}")

print("\nSUBJECT AVERAGES")
subject_averages = []
for j in range(len(subjects)):
    total = 0
    for i in range(len(marks)):
        total += marks[i][j]
    average = total / len(marks)
    subject_averages.append(average)
    print(f"{subjects[j]}: {average:.2f}")

top_index = 0
for i in range(1, len(student_totals)):
    if student_totals[i] > student_totals[top_index]:
        top_index = i

print(f"\nTop performer: {students[top_index]} "
      f"(total {student_totals[top_index]})")

lowest_subject_index = 0
for j in range(1, len(subject_averages)):
    if subject_averages[j] < subject_averages[lowest_subject_index]:
        lowest_subject_index = j

print(f"Lowest-average subject: {subjects[lowest_subject_index]} "
      f"({subject_averages[lowest_subject_index]:.2f})")
