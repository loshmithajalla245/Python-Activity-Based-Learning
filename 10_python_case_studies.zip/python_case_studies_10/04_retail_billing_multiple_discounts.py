# Case Study 4: Retail Billing with Multiple Discount Rules
# Concepts: lists, loops, arithmetic, conditions, strings

# Each product: name, category, unit price, quantity
products = [
    ["Notebook", "stationery", 50.00, 4],
    ["Headphones", "electronics", 1200.00, 1],
    ["Water bottle", "household", 250.00, 2],
    ["Pen pack", "stationery", 80.00, 3]
]

category_tax = {
    "stationery": 0.05,
    "electronics": 0.18,
    "household": 0.12
}

subtotal = 0
tax_total = 0
print("ITEMIZED RETAIL INVOICE")
print("-" * 78)
print(f"{'Product':<18}{'Qty':>5}{'Price':>10}{'Amount':>12}{'Tax':>10}{'Line total':>13}")
print("-" * 78)

for product in products:
    name, category, price, quantity = product
    amount = price * quantity
    tax = amount * category_tax[category]
    line_total = amount + tax
    subtotal += amount
    tax_total += tax
    print(f"{name:<18}{quantity:>5}{price:>10.2f}{amount:>12.2f}"
          f"{tax:>10.2f}{line_total:>13.2f}")

# Discount policy: 10% when subtotal >= Rs. 2,000, otherwise 5% when >= Rs. 1,000.
# Maximum discount is Rs. 500.
if subtotal >= 2000:
    discount = subtotal * 0.10
elif subtotal >= 1000:
    discount = subtotal * 0.05
else:
    discount = 0

if discount > 500:
    discount = 500

grand_total = subtotal - discount + tax_total
print("-" * 78)
print(f"Subtotal:       Rs. {subtotal:.2f}")
print(f"Discount:       Rs. {discount:.2f}")
print(f"Total tax:      Rs. {tax_total:.2f}")
print(f"Grand total:    Rs. {grand_total:.2f}")
