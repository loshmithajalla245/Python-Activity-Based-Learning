# Case Study 10: Tuple-Based Product Catalogue Audit
# Concepts: tuples, unpacking, loops, conditions, arithmetic

# Each product tuple: (product_id, name, unit_price, stock_quantity, reorder_level)
catalogue = [
    ("P101", "Notebook", 45.00, 120, 30),
    ("P102", "Calculator", 550.00, 8, 10),
    ("P103", "Pen", 12.50, 200, 50),
    ("P104", "Backpack", 850.00, 0, 5),
    ("P105", "Ruler", -15.00, 40, 10)  # Deliberately invalid price for audit
]

total_inventory_value = 0
invalid_count = 0

print("PRODUCT CATALOGUE AUDIT")
print("-" * 82)
print(f"{'ID':<8}{'Product':<15}{'Price':>10}{'Stock':>10}"
      f"{'Value':>12}{'Audit result':>25}")
print("-" * 82)

for product in catalogue:
    product_id, name, price, stock, reorder_level = product
    problems = []

    if price < 0:
        problems.append("Invalid price")
    if stock < 0:
        problems.append("Invalid stock")

    if len(problems) > 0:
        result = ", ".join(problems)
        invalid_count += 1
        value = 0
    else:
        value = price * stock
        total_inventory_value += value
        if stock == 0:
            result = "Out of stock"
        elif stock < reorder_level:
            result = "Reorder required"
        else:
            result = "OK"

    print(f"{product_id:<8}{name:<15}{price:>10.2f}{stock:>10}"
          f"{value:>12.2f}{result:>25}")

print("-" * 82)
print(f"Valid inventory value: Rs. {total_inventory_value:.2f}")
print(f"Invalid records: {invalid_count}")
