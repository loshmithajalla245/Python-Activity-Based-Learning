# Case Study 7: Student Timetable Conflict Detection
# Concepts: strings, tuples, lists, nested loops, conditions

# Each class is a tuple: (course, day, start_hour, end_hour, room)
timetable = [
    ("Python", "Monday", 9, 11, "Lab-1"),
    ("Mathematics", "Monday", 10, 12, "Room-2"),
    ("English", "Tuesday", 9, 10, "Room-1"),
    ("Physics", "Monday", 11, 13, "Lab-1"),
    ("Computing", "Tuesday", 9, 11, "Room-1")
]

print("TIMETABLE CONFLICT REPORT")
conflicts_found = False

for i in range(len(timetable)):
    course1, day1, start1, end1, room1 = timetable[i]

    for j in range(i + 1, len(timetable)):
        course2, day2, start2, end2, room2 = timetable[j]

        if day1 == day2 and start1 < end2 and start2 < end1:
            conflicts_found = True
            if room1 == room2:
                print(f"ROOM CONFLICT: {course1} and {course2} use {room1} "
                      f"at overlapping times on {day1}.")
            else:
                print(f"TIME CONFLICT: {course1} ({start1}:00-{end1}:00) and "
                      f"{course2} ({start2}:00-{end2}:00) overlap on {day1}.")

if not conflicts_found:
    print("No conflicts found.")

# Check whether each room is in the permitted room list.
available_rooms = ["Room-1", "Room-2", "Lab-1"]
print("\nROOM VALIDATION")
for course, day, start, end, room in timetable:
    if room not in available_rooms:
        print(f"{course}: unavailable room {room}")
    else:
        print(f"{course}: {room} is available in the room list.")
