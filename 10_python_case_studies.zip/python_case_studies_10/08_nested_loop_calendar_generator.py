# Case Study 8: Nested Loop Calendar Generator
# Concepts: variables, loops, nested loops, conditions, formatted strings

month = "Sample Month"
starting_weekday = 3  # Monday=0, Tuesday=1, ..., Sunday=6
days_in_month = 30

if starting_weekday < 0 or starting_weekday > 6:
    print("Invalid starting weekday. Enter a number from 0 to 6.")
elif days_in_month < 28 or days_in_month > 31:
    print("Invalid month length. Enter a number from 28 to 31.")
else:
    print(f"\n{month}")
    print("Mon Tue Wed Thu Fri Sat Sun")
    print("--- --- --- --- --- --- ---")

    day = 1
    # The first week may start with blank positions.
    for week in range(6):
        line = ""
        for weekday in range(7):
            if (week == 0 and weekday < starting_weekday) or day > days_in_month:
                line += "    "
            else:
                line += f"{day:>3} "
                day += 1

        print(line.rstrip())
        if day > days_in_month:
            break
