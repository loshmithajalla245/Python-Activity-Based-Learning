# Case Study 2: Progressive Electricity Billing
# Concepts: variables, arithmetic, conditions, loops, lists

def calculate_bill(units):
    if units < 0:
        return None

    # Slab rates: first 100 units at Rs. 2, next 100 at Rs. 3,
    # next 200 at Rs. 5, and units above 400 at Rs. 7.
    remaining = units
    energy_charge = 0

    slab_units = [100, 100, 200]
    slab_rates = [2, 3, 5]

    for i in range(len(slab_units)):
        used = min(remaining, slab_units[i])
        energy_charge += used * slab_rates[i]
        remaining -= used

    if remaining > 0:
        energy_charge += remaining * 7

    fixed_charge = 75
    surcharge = energy_charge * 0.05
    rebate = 20 if units < 100 else 0
    total = energy_charge + fixed_charge + surcharge - rebate
    return energy_charge, fixed_charge, surcharge, rebate, total


monthly_units = [85, 110, 145, 310, 455, 470]
previous_bill = None

print("MONTHLY ELECTRICITY BILL")
print("Month | Units | Energy | Fixed | Surcharge | Rebate | Total | Note")

for month_index, units in enumerate(monthly_units, start=1):
    result = calculate_bill(units)
    energy, fixed, surcharge, rebate, total = result
    note = ""

    if previous_bill is not None and total > previous_bill * 1.25:
        note = "Unusual increase"
    print(f"{month_index:>5} | {units:>5} | {energy:>6.2f} | {fixed:>5.2f} | "
          f"{surcharge:>9.2f} | {rebate:>6.2f} | {total:>7.2f} | {note}")
    previous_bill = total
